


cname = """unix shell scripting"""
print(cname)


"""this is commented line"""