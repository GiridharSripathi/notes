
name = "python programming"
# displaying the upper case
print(name.upper())
print(name.lower())

print(name.center(30))
print(name.center(30,"*"))

print(name.capitalize())

output = name.split(" ")
print(output)

getcount = name.count("p")
print(getcount)

print(name.find("prog"))  #7

print(name.find("pen"))  #-1

print(name.isupper())

if name.isupper():
    print("String is upper")
    print("Inside print")
    print("Still inside print")
else:
    print("String is lower")

#1
if name.find("prog") >= 0 :
    print("Substring exists")
else:
    print("doesnt exist")

#2 :to check whether the substring exists or not
if "prog" in name :
    print("Substring exists")
else:
    print("doesnt exist")


if name.startswith("pyt"):
    print("python programming")
else:
    print("Starting with something else")


aname = " python "
print(aname.strip())  # will remove the whitespaces at the ends
print(aname.lstrip()) # only at left side
print(aname.rstrip()) # only at right side


name = "I love {} and {}"

print(name.format("python","perl"))
















