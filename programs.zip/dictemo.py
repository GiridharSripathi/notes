


book = {"chap1":10 ,"chap2":20 ,"chap3":30 }

print(book["chap1"])  #10



aset ={10,20,30,30,30,40}
print(aset)