
name = "python programming"
# string[start:stop:step]
print(name[0])   # p
print(name[1])   # y
print(name[0:5]) # pytho
print(name[4:7]) # on
print(name[::])  # python programming
print(name[:])   # python programming
print(name[0:17:2])  #pto rgamn
print(name[1:17:2])  #yhnpormi
print(name[4:17:4])  #oran
print(name[-1])      #g
print(name[::-1])    #gnimmargorp nohtyp
print(name[-7:-2])